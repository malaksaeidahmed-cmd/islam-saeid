import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getFirestore, collection, onSnapshot, addDoc, deleteDoc, doc, updateDoc,
  increment, getDoc, setDoc, query, where, getDocs, orderBy, limit
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
// ✅ مصدر واحد للحقيقة
import { firebaseConfig, SUPER_ADMIN_UID } from '../firebase-config.js';

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
const db = getFirestore(app);

const MAX_REVISIONS_PER_POST = 5;

async function initDefaults() {
  try {
    const analyticsRef = doc(db, "analytics", "main");
    const snap = await getDoc(analyticsRef);
    if (!snap.exists()) {
      await setDoc(analyticsRef, {
        visits: 0, leads: 0, pdfDownloads: 0,
        bootcampOpen: true, maintenanceMode: false
      });
    } else {
      const data = snap.data();
      if (data.maintenanceMode === undefined) {
        await updateDoc(analyticsRef, { maintenanceMode: false });
      }
      if (data.bootcampOpen === undefined) {
        await updateDoc(analyticsRef, { bootcampOpen: true });
      }
    }
  } catch (e) {
    console.error("Init Error:", e);
  }
}

initDefaults();

async function trimRevisions(postId) {
  try {
    const q = query(
      collection(db, "blog_revisions"),
      where("postId", "==", postId),
      orderBy("savedAt", "desc")
    );
    const snap = await getDocs(q);
    if (snap.size <= MAX_REVISIONS_PER_POST) return;
    const toDelete = snap.docs.slice(MAX_REVISIONS_PER_POST);
    for (const d of toDelete) {
      try { await deleteDoc(doc(db, "blog_revisions", d.id)); } catch (_) {}
    }
  } catch (err) {
    console.warn('trimRevisions error:', err);
  }
}

export const CloudCMS = {
  // ==================== Users/Admins ====================
  subscribeUsers(callback) {
    return onSnapshot(collection(db, "admins"), (snapshot) => {
      const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
      callback(items);
    });
  },

  // ==================== Portfolio ====================
  subscribePortfolio(callback) {
    return onSnapshot(collection(db, "portfolio"), (snapshot) => {
      const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      callback(items);
    });
  },

  async addPortfolioItem(data) {
    return await addDoc(collection(db, "portfolio"), {
      ...data,
      mediaGallery: Array.isArray(data.mediaGallery) ? data.mediaGallery : [],
      views: 0, likes: 0, createdAt: Date.now()
    });
  },

  async updatePortfolioItem(id, data) {
    return await updateDoc(doc(db, "portfolio", id), { ...data, updatedAt: Date.now() });
  },

  async deletePortfolioItem(id) {
    return await deleteDoc(doc(db, "portfolio", id));
  },

  async getPortfolioItemById(id) {
    const itemRef = doc(db, "portfolio", id);
    const snap = await getDoc(itemRef);
    if (snap.exists()) {
      try { await updateDoc(itemRef, { views: increment(1) }); } catch (_) {}
      return { id: snap.id, ...snap.data() };
    }
    return null;
  },

  async getPortfolioItemBySlug(slug) {
    if (!slug) return null;
    try {
      const q = query(collection(db, "portfolio"), where("slug", "==", slug));
      const snap = await getDocs(q);
      if (snap.empty) return null;
      const first = snap.docs[0];
      try { await updateDoc(doc(db, "portfolio", first.id), { views: increment(1) }); } catch (_) {}
      return { id: first.id, ...first.data() };
    } catch (error) {
      console.error('getPortfolioItemBySlug error:', error);
      return null;
    }
  },

  async likePortfolioItem(id) {
    await updateDoc(doc(db, "portfolio", id), { likes: increment(1) });
  },

  // ==================== Blog ====================
  subscribeBlog(callback, includeScheduled = false) {
    return onSnapshot(collection(db, "blog"), (snapshot) => {
      let items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      if (!includeScheduled) {
        items = items.filter(p => !p.status || p.status === 'published');
      }
      callback(items);
    });
  },

  async addBlogPost(data) {
    return await addDoc(collection(db, "blog"), {
      ...data,
      status: data.status || 'published',
      views: 0, likes: 0, createdAt: Date.now()
    });
  },

  async updateBlogPost(id, data) {
    return await updateDoc(doc(db, "blog", id), { ...data, updatedAt: Date.now() });
  },

  async deleteBlogPost(id) {
    return await deleteDoc(doc(db, "blog", id));
  },

  async getBlogPostById(id) {
    const itemRef = doc(db, "blog", id);
    const snap = await getDoc(itemRef);
    if (snap.exists()) {
      try { await updateDoc(itemRef, { views: increment(1) }); } catch (_) {}
      return { id: snap.id, ...snap.data() };
    }
    return null;
  },

  async getBlogPostBySlug(slug) {
    if (!slug) return null;
    try {
      const q = query(collection(db, "blog"), where("slug", "==", slug));
      const snap = await getDocs(q);
      if (snap.empty) return null;
      const first = snap.docs[0];
      try { await updateDoc(doc(db, "blog", first.id), { views: increment(1) }); } catch (_) {}
      return { id: first.id, ...first.data() };
    } catch (error) {
      console.error('getBlogPostBySlug error:', error);
      return null;
    }
  },

  async likeBlogPost(id) {
    await updateDoc(doc(db, "blog", id), { likes: increment(1) });
  },

  // ==================== Revisions ====================
  async saveRevision(postId, postData, meta = {}) {
    if (!postId || !postData) return null;
    try {
      const revisionPayload = {
        postId,
        title: postData.title || '',
        category: postData.category || '',
        image: postData.image || '',
        video: postData.video || '',
        excerpt: postData.excerpt || '',
        content: postData.content || '',
        contentFormat: postData.contentFormat || 'html',
        slug: postData.slug || '',
        metaTitle: postData.metaTitle || '',
        metaDescription: postData.metaDescription || '',
        focusKeyword: postData.focusKeyword || '',
        tags: Array.isArray(postData.tags) ? postData.tags : [],
        keyTakeaways: Array.isArray(postData.keyTakeaways) ? postData.keyTakeaways : [],
        faqItems: Array.isArray(postData.faqItems) ? postData.faqItems : [],
        readingTime: postData.readingTime || 1,
        author: postData.author || 'إسلام سعيد',
        authorBio: postData.authorBio || '',
        savedAt: Date.now(),
        savedBy: meta.savedBy || 'unknown',
        savedByEmail: meta.savedByEmail || '',
        reason: meta.reason || 'update'
      };
      const docRef = await addDoc(collection(db, "blog_revisions"), revisionPayload);
      await trimRevisions(postId);
      return docRef.id;
    } catch (error) {
      console.error('saveRevision error:', error);
      throw error;
    }
  },

  subscribeRevisions(postId, callback) {
    if (!postId) { callback([]); return () => {}; }
    const q = query(collection(db, "blog_revisions"), where("postId", "==", postId));
    return onSnapshot(q, (snapshot) => {
      const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0));
      callback(items);
    });
  },

  async getRevisions(postId) {
    if (!postId) return [];
    try {
      const q = query(collection(db, "blog_revisions"), where("postId", "==", postId));
      const snap = await getDocs(q);
      return snap.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0));
    } catch (error) {
      console.error('getRevisions error:', error);
      return [];
    }
  },

  async deleteRevision(revisionId) {
    if (!revisionId) return;
    try { await deleteDoc(doc(db, "blog_revisions", revisionId)); }
    catch (error) { console.error('deleteRevision error:', error); throw error; }
  },

  // ==================== Scheduled ====================
  async scheduleBlogPost(id, scheduledAt) {
    if (!id || !scheduledAt) throw new Error('Missing data');
    await updateDoc(doc(db, "blog", id), {
      status: 'scheduled',
      scheduledAt: new Date(scheduledAt).toISOString(),
      updatedAt: Date.now()
    });
  },

  async unscheduleBlogPost(id) {
    if (!id) throw new Error('Post ID required');
    await updateDoc(doc(db, "blog", id), {
      status: 'published', scheduledAt: null, updatedAt: Date.now()
    });
  },

  // ==================== Drafts ====================
  async saveDraft(draftId, data) {
    try {
      const draftRef = draftId
        ? doc(db, 'blog_drafts', draftId)
        : doc(collection(db, 'blog_drafts'));
      const payload = { ...data, status: 'draft', updatedAt: Date.now() };
      if (!draftId) {
        payload.createdAt = Date.now();
      } else {
        const existing = await getDoc(draftRef);
        if (existing.exists() && existing.data().createdAt) {
          payload.createdAt = existing.data().createdAt;
        } else {
          payload.createdAt = Date.now();
        }
      }
      await setDoc(draftRef, payload, { merge: true });
      return draftRef.id;
    } catch (error) { console.error('saveDraft error:', error); throw error; }
  },

  async getDraft(draftId) {
    if (!draftId) return null;
    try {
      const snap = await getDoc(doc(db, 'blog_drafts', draftId));
      return snap.exists() ? { id: snap.id, ...snap.data() } : null;
    } catch (error) { return null; }
  },

  async deleteDraft(draftId) {
    if (!draftId) return;
    try { await deleteDoc(doc(db, 'blog_drafts', draftId)); }
    catch (error) { console.error('deleteDraft error:', error); throw error; }
  },

  subscribeDrafts(callback) {
    return onSnapshot(collection(db, 'blog_drafts'), (snapshot) => {
      const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
      callback(items);
    });
  },

  // ==================== Comments ====================
  subscribeComments(postId, callback) {
    const q = query(collection(db, "comments"), where("postId", "==", postId), where("approved", "==", true));
    return onSnapshot(q, (snapshot) => {
      const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => b.createdAt - a.createdAt);
      callback(items);
    });
  },

  subscribeAllComments(callback) {
    return onSnapshot(collection(db, "comments"), (snapshot) => {
      const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => b.createdAt - a.createdAt);
      callback(items);
    });
  },

  async addComment(postId, name, content) {
    return await addDoc(collection(db, "comments"), {
      postId, name, content, approved: false, createdAt: Date.now()
    });
  },

  async approveComment(id) {
    await updateDoc(doc(db, "comments", id), { approved: true });
  },

  async deleteComment(id) {
    return await deleteDoc(doc(db, "comments", id));
  },

  // ==================== System ====================
  async toggleBootcampStatus(status) {
    await updateDoc(doc(db, "analytics", "main"), { bootcampOpen: status });
  },

  async toggleMaintenanceMode(status) {
    await updateDoc(doc(db, "analytics", "main"), { maintenanceMode: status });
  },

  subscribeAnalytics(callback) {
    return onSnapshot(doc(db, "analytics", "main"), (snap) => {
      callback(snap.data() || {
        visits: 0, leads: 0, pdfDownloads: 0,
        bootcampOpen: true, maintenanceMode: false
      });
    });
  },

  subscribeEventLogs(callback, maxItems = 50) {
    return onSnapshot(collection(db, "event_logs"), (snapshot) => {
      const logs = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0))
        .slice(0, maxItems);
      callback(logs);
    });
  },

  async trackVisit() {
    try { await updateDoc(doc(db, "analytics", "main"), { visits: increment(1) }); } catch (_) {}
  },

  async logEvent(type, details) {
    try {
      const analyticsRef = doc(db, "analytics", "main");
      if (type === "PDF Download") await updateDoc(analyticsRef, { pdfDownloads: increment(1) });
      if (type === "Bootcamp Lead") await updateDoc(analyticsRef, { leads: increment(1) });
      await addDoc(collection(db, "event_logs"), {
        type, details,
        timestamp: Date.now(),
        dateString: new Date().toLocaleString("ar-EG")
      });
    } catch (e) {
      console.warn("logEvent failed:", e);
    }
  }
};
